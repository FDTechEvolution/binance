

<?php $__env->startSection('title', 'FEATURE'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card-box table-responsive">
                <h4 class="m-t-0 header-title"><b>Features</b></h4>

                <button type="button" class="btn btn-sm btn-primary mb-2" 
                        data-toggle="modal" data-target="#featureAddModal"
                >+ ADD</button>

                <table id="datatable" class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center"><small>#</small></th>
                            <th>Coin</th>
                            <th>Type</th>
                            <th>Entry</th>
                            <th>Target</th>
                            <th>Stop Loss</th>
                            <th>AVG Price</th>
                            <th class="text-center">Status</th>
                            <th>Docdate</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                        <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><small><?php echo e($key+1); ?></small></td>
                                <td><?php echo e($feature->coin_name); ?></td>
                                <td><?php echo e($feature->type); ?></td>
                                <td><?php echo e($feature->entry1); ?></td>
                                <td><?php echo e($feature->target1); ?></td>
                                <td><?php echo e($feature->stop_loss); ?></td>
                                <td><?php echo e($feature->avg_price); ?></td>
                                <td class="text-center"><?php echo e($feature->status); ?></td>
                                <td><?php echo e($feature->docdate); ?></td>
                                <td class="text-center">xxx</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('feature.modal.add-feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('app/feature.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.coreLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-binance\binance\resources\views/feature/index.blade.php ENDPATH**/ ?>