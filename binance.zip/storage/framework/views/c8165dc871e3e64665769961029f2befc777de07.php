<div class="left side-menu">
    <div class="sidebar-inner slimscrollleft">
        <!--- Divider -->
        <div id="sidebar-menu">
            <ul>
                <li class="menu-title">Main</li>

                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect waves-primary"><i
                            class="ti-home"></i><span> Dashboard </span></a>
                </li>

                <li>
                    <a href="<?php echo e(route('features')); ?>" class="waves-effect waves-primary"><i
                            class="ti-home"></i><span> Features </span></a>
                </li>

                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect waves-primary"><i class="ti-paint-bucket"></i> <span> UI Kit </span>
                        <span class="menu-arrow"></span></a>
                    <ul class="list-unstyled">
                        <li><a href="ui-buttons.html">Buttons</a></li>
                        <li><a href="ui-cards.html">Cards</a></li>
                        <li><a href="ui-portlets.html">Portlets</a></li>
                        <li><a href="ui-checkbox-radio.html">Checkboxs-Radios</a></li>
                        <li><a href="ui-tabs.html">Tabs & Accordions</a></li>
                        <li><a href="ui-modals.html">Modals</a></li>
                        <li><a href="ui-progressbars.html">Progress Bars</a></li>
                        <li><a href="ui-notification.html">Notification</a></li>
                        <li><a href="ui-bootstrap.html">BS Elements</a></li>
                    </ul>
                </li>

                <li>
                    <a href="typography.html" class="waves-effect waves-primary"><i
                            class="ti-infinite"></i><span> Typography </span><span
                            class="badge badge-pink pull-right">1</span></a>
                </li>

            </ul>

            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel-binance\binance\resources\views/layouts/components/left-side-bar.blade.php ENDPATH**/ ?>