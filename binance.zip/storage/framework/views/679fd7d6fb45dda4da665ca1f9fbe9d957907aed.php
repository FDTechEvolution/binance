<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <!-- Scripts -->
        <!-- <script src="<?php echo e(asset('js/app.js')); ?>" defer></script> -->

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('plugins/switchery/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('plugins/morris/morris.css')); ?>" rel="stylesheet">

        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/icons.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/my_style.css')); ?>" rel="stylesheet">

        <?php echo $__env->yieldContent('style'); ?>

        <script src="<?php echo e(asset('js/modernizr.min.js')); ?>"></script>

        <!-- Axios -->
        <script src="https://unpkg.com/axios/dist/axios.min.js"></script>

    </head>
    <body class="fixed-left">
        <!-- Begin page -->
        <div id="wrapper">
            <?php echo $__env->make('layouts.components.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('layouts.components.left-side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="container-fluid">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>

                <footer class="footer text-right">
                    2017 © Minton.
                </footer>
            </div>

            <?php echo $__env->make('layouts.components.right-side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

        <?php echo $__env->yieldContent('modal'); ?>

        <script>
            var resizefunc = [];
        </script>

        <!-- Plugins  -->
        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/detect.js')); ?>"></script>
        <script src="<?php echo e(asset('js/fastclick.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.slimscroll.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.blockUI.js')); ?>"></script>
        <script src="<?php echo e(asset('js/waves.js')); ?>"></script>
        <script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.nicescroll.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.scrollTo.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/switchery/switchery.min.js')); ?>"></script>
        
        <!-- Counter Up  -->
        <script src="<?php echo e(asset('plugins/waypoints/lib/jquery.waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/counterup/jquery.counterup.min.js')); ?>"></script>

        <!--Morris Chart-->
        <script src="<?php echo e(asset('plugins/morris/morris.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/raphael/raphael-min.js')); ?>"></script>

        <!-- Page js  -->
        <script src="<?php echo e(asset('pages/jquery.dashboard.js')); ?>"></script>

        <!-- Custom main Js -->
        <script src="<?php echo e(asset('js/jquery.core.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.app.js')); ?>"></script>
        
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('.counter').counterUp({
                    delay: 100,
                    time: 1200
                });
            });
        </script>

        <?php echo $__env->yieldContent('script'); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\laravel-binance\binance\resources\views/layouts/coreLayout.blade.php ENDPATH**/ ?>