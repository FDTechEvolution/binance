<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

use App\Models\Feature;

class FeatureController extends Controller
{
    public function index() {
        $features = Feature::get();
        return view('features.index', ['features' => $features]);
    }

    public function create(Request $request) {
        $feature = Feature::create([
                    'coin_name' => strtoupper($request->coin),
                    'type' => $request->type,
                    'entry1' => $request->entry1,
                    'entry2' => $request->entry2,
                    'entry3' => $request->entry3,
                    'target1' => $request->target1,
                    'target2' => $request->target2,
                    'target3' => $request->target3,
                    'stop_loss' => $request->stop_loss,
                    'avg_price' => $request->avg_price,
                    'usdt_pnl' => $request->usdt_pnl,
                    'docdate' => $request->docdate,
                    'status' => $request->status,
                    'description' => $request->description
                ]);

        if($feature) return redirect()->back()->with('success', 'Add feature successed.');
    }

    public function update(Request $request) {
        $feature = Feature::find($request->e_id);
        $feature->update([
            'coin_name' => strtoupper($request->coin),
            'type' => $request->type,
            'entry1' => $request->entry1,
            'entry2' => $request->entry2,
            'entry3' => $request->entry3,
            'target1' => $request->target1,
            'target2' => $request->target2,
            'target3' => $request->target3,
            'stop_loss' => $request->stop_loss,
            'avg_price' => $request->avg_price,
            'usdt_pnl' => $request->usdt_pnl,
            'docdate' => $request->docdate,
            'status' => $request->status,
            'description' => $request->description
        ]);

        if($feature) return redirect()->back();
    }

    public function delete(Request $request) {
        Log::debug($request->id);
        return redirect()->back();
    }
}
